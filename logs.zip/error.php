<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Error</title>
</head>
<body>
    <h1>Payment Error</h1>
    <p>There was an error initiating your payment. Please try again later.</p>
<button type="button" class="btn btn-success" onclick="window.location.href='index.html'">Go back to the home page</button>


</body>
</html>
