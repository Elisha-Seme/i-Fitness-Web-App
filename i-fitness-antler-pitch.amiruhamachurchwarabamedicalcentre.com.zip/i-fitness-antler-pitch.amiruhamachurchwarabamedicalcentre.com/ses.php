<?php

session_start();
 echo "Session: " . print_r($_SESSION, true); ?>