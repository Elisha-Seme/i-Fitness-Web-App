<?php
define('CONSUMER_KEY', 'mBC5UuhgWuQAr498tTehL47VaoJUdALHcCcgCNvnOyoJZOln');
define('CONSUMER_SECRET', '2sCyrk1kf5ZlAhcFHXASvjMeYqZZBWv7S516AOLsYowTpC9eHluiSKehnZ9lmfYK');
define('SHORTCODE', '174379');
define('PASSKEY', 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919');
define('CALLBACK_URL', 'https://i-fitness-antler-pitch.amiruhamachurchwarabamedicalcentre.com/mpesa_callback.php');
?>
